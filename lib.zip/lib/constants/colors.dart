import 'package:flutter/material.dart';

class MainColor {
  static Color primaryColor = Color(0xFF4169E8);
  static Color secondaryColor = Color(0xFFffca27);
  static Color accentColor = Color(0xFFff4B4B);
}